# Travel Test Engine v1.2 (Arabic / RTL)

صفحة واحدة Static تعمل على أي استضافة (GitHub Pages / Netlify / Vercel).  
أسئلة عشوائية بدون تبويبات، 650+ قابلة للتوسيع حتى 750+. حفظ تلقائي، تصدير JSON/CSV، تحليل فردي، ودمج جماعي.

## النشر السريع — GitHub Pages
1) أنشئ مستودعًا عامًّا باسم `travel-test-engine`.
2) أضف ملف `index.html` (هذا الملف).
3) Settings → Pages → Branch: `main` /root → Save.
4) رابطك سيكون: `https://USERNAME.github.io/travel-test-engine/`.

## النشر البديل
- Netlify: Import from GitHub → Deploy.
- Vercel: New Project → Other (Static) → Deploy.

## الاستخدام
- روابط جلسات منفصلة: `...?user=Reema`, `...?user=Raghad`, `...?user=Rahaf`.
- بعد الإنهاء: Export JSON لكل شخص. في صفحتك: Import multiple JSON → Merge → تحصلين على مصفوفة توافق جماعية.

## ملاحظات
- لا أسئلة جنسية/دينية. النبرة قد تكون “وقاحة قصوى” لكن غير شخصية حسّاسة.
- كل البيانات محلية (localStorage). لا سيرفر.
